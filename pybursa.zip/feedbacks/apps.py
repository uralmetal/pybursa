from django.apps import AppConfig


class FeedbacksConfig(AppConfig):
    name = 'feedbacks'
