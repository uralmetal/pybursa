from django.apps import AppConfig


class QuadraticConfig(AppConfig):
    name = 'quadratic'
