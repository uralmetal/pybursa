from django.apps import AppConfig


class CoachesConfig(AppConfig):
    name = 'coaches'
