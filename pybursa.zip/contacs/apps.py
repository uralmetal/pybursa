from django.apps import AppConfig


class ContacsConfig(AppConfig):
    name = 'contacs'
